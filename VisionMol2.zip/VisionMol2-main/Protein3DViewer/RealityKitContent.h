//
//  RealityKitContent.h
//  Protein3DViewer
//
//  Created on 2025/6/18.
//

#ifndef RealityKitContent_h
#define RealityKitContent_h

// 这个头文件为RealityKitContent模块提供C接口
// 实际实现在Swift文件中

#endif /* RealityKitContent_h */