import Foundation

public enum SecondaryStructure {
    case helix
    case sheet
    case loop
} 