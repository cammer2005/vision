import SwiftUI

struct SamplePDBPickerView: View {
	@EnvironmentObject private var appModel: AppModel
	@Environment(\.dismiss) private var dismiss
	
	var body: some View {
		NavigationStack {
			List {
				ForEach(appModel.listSamplePDBURLs(), id: \.name) { item in
					Button(action: {
						Task {
							await appModel.openPDBFile(url: item.url)
							dismiss()
						}
					}) {
						HStack {
							Image(systemName: "doc.text")
							Text(item.name)
								.font(.system(size: 20))
							Spacer()
							Image(systemName: "chevron.right")
								.foregroundStyle(.secondary)
						}
					}
				}
			}
			.navigationTitle("Sample PDB Files")
			.toolbar {
				ToolbarItem(placement: .topBarTrailing) {
					Button("Close") { dismiss() }
				}
			}
		}
	}
}

#Preview {
	SamplePDBPickerView()
		.environmentObject(AppModel())
} 