import SwiftUI
import RealityKit

struct CollaborationView: View {
    @EnvironmentObject var appModel: AppModel
    
    @State private var showJoinAlert = false
    @State private var showHostAlert = false
    @State private var showExitConfirmation = false
    @State private var isConnecting = false
    @State private var showSyncRequest = false
    @State private var syncRequestFrom = ""
    
    var body: some View {
        VStack {
            // 返回按钮
            HStack {
                Button(action: {
                    if appModel.collaborationManager?.isConnected == true {
                        showExitConfirmation = true
                    } else {
                        appModel.showCollaborationView = false
                    }
                }) {
                    Label("Back", systemImage: "chevron.left")
                        .font(.system(size: 20, weight: .medium))
                }
                .buttonStyle(.bordered)
                .padding(.leading)
                Spacer()
            }
            // 状态显示
            statusView
            // 控制按钮
            controlButtons
            // 用户列表
            userListView
        }
        .padding()
        .onAppear {
            // 确保协作管理器被初始化
            if appModel.collaborationManager == nil {
                appModel.initializeCollaboration()
            }
        }
        .onDisappear {
            // 如果用户完全退出协作视图，清理协作组件
            if !appModel.collaborationManager!.isConnected {
                appModel.cleanupCollaboration()
            }
        }
        .alert("Join Collaboration", isPresented: $showJoinAlert) {
            Button("Confirm") {
                isConnecting = true
                appModel.collaborationManager?.joinSession()
            }
            Button("Cancel", role: .cancel) {
                isConnecting = false
            }
        } message: {
            Text("Searching for available collaboration...")
        }
        .alert("Create Collaboration", isPresented: $showHostAlert) {
            Button("Confirm") {
                isConnecting = true
                appModel.collaborationManager?.startHosting()
            }
            Button("Cancel", role: .cancel) {
                isConnecting = false
            }
        } message: {
            Text("New collaboration will create")
        }
        .alert("Exit collaboration", isPresented: $showExitConfirmation) {
            Button("Exit interface") {
                appModel.showCollaborationView = false
            }
            Button("Exit collaboration", role: .destructive) {
                appModel.collaborationManager?.leaveSession()
                appModel.showCollaborationView = false
            }
            Button("Cancel", role: .cancel) {}
        }
        // 同步请求确认对话框
        .alert("Synchronous Request", isPresented: $showSyncRequest) {
            Button("Accept") {
                if let peer = appModel.collaborationManager?.connectedPeers.first {
                    appModel.collaborationManager?.handleSyncRequest(from: peer, accept: true)
                }
            }
            Button("Refuse", role: .cancel) {
                if let peer = appModel.collaborationManager?.connectedPeers.first {
                    appModel.collaborationManager?.handleSyncRequest(from: peer, accept: false)
                }
            }
        } message: {
            Text("\(syncRequestFrom) Request to synchronize the current model")
        }
        .onChange(of: appModel.collaborationManager?.showSyncRequest) { _, newValue in
            if let newValue = newValue {
                showSyncRequest = newValue
            }
        }
        .onChange(of: appModel.collaborationManager?.syncRequestFrom) { _, newValue in
            if let newValue = newValue {
                syncRequestFrom = newValue
            }
        }
    }
    
    // MARK: - Subviews
    private var statusView: some View {
        HStack {
            Image(systemName: appModel.collaborationManager?.isConnected == true ? "circle.fill" : "circle")
                .foregroundColor(appModel.collaborationManager?.isConnected == true ? .green : .red)
            Text(appModel.collaborationManager?.isConnected == true ? "Connected" : "NOT Connected")
                .foregroundColor(appModel.collaborationManager?.isConnected == true ? .green : .red)
            if let error = appModel.collaborationManager?.errorMessage {
                Text(error)
                    .foregroundColor(.red)
            }
        }
    }
    
    private var controlButtons: some View {
        HStack {
            Button(action: {
                showHostAlert = true
            }) {
                Label("Create Collaboration", systemImage: "plus.circle")
            }
            .disabled(appModel.collaborationManager?.isHosting == true || isConnecting)
            Button(action: {
                showJoinAlert = true
            }) {
                Label("Join Collaboration", systemImage: "person.2.circle")
            }
            .disabled(appModel.collaborationManager?.isConnected == true || isConnecting)
            Button(action: {
                appModel.collaborationManager?.leaveSession()
                isConnecting = false
            }) {
                Label("Exit Collaboration", systemImage: "xmark.circle")
            }
            .disabled(!(appModel.collaborationManager?.isConnected == true))
            if appModel.collaborationManager?.isConnected == true && appModel.collaborationManager?.isHost == false {
                Button(action: {
                    appModel.collaborationManager?.requestModelSync()
                }) {
                    Label("synchronize model", systemImage: "arrow.triangle.2.circlepath")
                }
            }
        }
    }
    
    private var userListView: some View {
        List {
            ForEach(appModel.userRepresentation?.connectedUsers.values.map { $0 } ?? [], id: \.id) { user in
                HStack {
                    Circle()
                        .fill(.blue)
                        .frame(width: 10, height: 10)
                    Text(user.name)
                    Spacer()
                    Text("Online")
                        .foregroundColor(.green)
                }
            }
        }
    }
} 
