static let atomRadii: [String: Float] = [
    "H": 0.075, "C": 0.125, "N": 0.115, "O": 0.10, "P": 0.175,
    "S": 0.175, "FE": 0.20, "ZN": 0.20, "MG": 0.20, "CA": 0.225
] 