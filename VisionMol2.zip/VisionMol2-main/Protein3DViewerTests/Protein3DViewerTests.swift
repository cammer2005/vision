//
//  Protein3DViewerTests.swift
//  Protein3DViewerTests
//
//  Created by 123 on 2025/4/16.
//

import Testing
@testable import Protein3DViewer

struct Protein3DViewerTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
